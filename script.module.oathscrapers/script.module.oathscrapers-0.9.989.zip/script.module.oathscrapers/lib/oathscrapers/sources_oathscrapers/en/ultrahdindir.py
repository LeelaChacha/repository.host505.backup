# -*- coding: UTF-8 -*-
# Re-written for TheOath

import re

try:
    from urlparse import parse_qs, urljoin
    from urllib import urlencode, quote_plus
except ImportError:
    from urllib.parse import parse_qs, urljoin, urlencode, quote_plus

from six import ensure_str

from oathscrapers.modules import client
from oathscrapers.modules import debrid
from oathscrapers.modules import dom_parser
from oathscrapers.modules import source_utils
from oathscrapers.modules import log_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['ultrahdindir.com']
        self.base_link = 'https://ultrahdindir.com'
        self.search_link = '/index.php?do=search&subaction=search&search_start=0&full_search=0&result_from=1&story=%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year}
            url = urlencode(url)
            return url
        except:
            log_utils.log('ultrahd_exc3', 1)
            return


    def sources(self, url, hostDict, hostprDict):
        sources = []
        try:
            if url == None:
                return sources
            if debrid.status() is False:
                return sources
            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])
            title = data['title'].replace(':', '').lower()
            year = data['year']
            query = '%s %s' % (data['title'], data['year'])
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            url = urljoin(self.base_link, self.search_link % quote_plus(query))
            r = ensure_str(client.request(url), errors='replace')
            #log_utils.log('ultrahd_r ' + str(r))
            r = client.parseDOM(r, 'div', attrs={'class': 'box-out margin'})
            r = [(dom_parser.parse_dom(i, 'div', attrs={'class':'news-title'})) for i in r if data['imdb'] in i]
            r = [(dom_parser.parse_dom(i[0], 'a', req='href')) for i in r if i]
            r = [(i[0].attrs['href'], i[0].content) for i in r if i]
            hostDict = hostprDict + hostDict
            for item in r:
                try:
                    data = client.request(item[0])
                    data = dom_parser.parse_dom(data, 'div', attrs={'id': 'r-content'})
                    details = client.parseDOM(data[0].content, 'div', attrs={'class': 'text_spoiler'})[0]
                    urls = re.findall(r'\s*<u><a href="(.+?)".+?</a></u>', data[0].content, re.DOTALL)
                    _zip = zip([u for u in urls if u.startswith('https://turbobit')], re.findall(r'General : (.+?)<br', details), re.findall(r'Length : (.+?) for', details))
                    for z in _zip:
                        #log_utils.log('ultrahd__infos ' + str(z))
                        try:
                            url = ensure_str(client.replaceHTMLCodes(z[0]))
                            name = ensure_str(client.replaceHTMLCodes(z[1]))
                            info = []
                            quality, info = source_utils.get_release_quality(name, url)

                            try:
                                size = re.findall('((?:\d+\.\d+|\d+\,\d+|\d+)\s*(?:GB|GiB|MB|MiB))', z[2])[0]
                                dsize, isize = source_utils._size(size)
                            except:
                                dsize, isize = 0.0, ''
                            info.insert(0, isize)

                            info = ' | '.join(info)
                            if any(x in url for x in ['.rar', '.zip', '.iso']):
                                raise Exception()
                            # if not 'turbobit' in url:
                                # continue
                            sources.append({'source': 'turbobit', 'quality': quality, 'language': 'en', 'url': url, 'info': info, 'size': dsize, 'name': name, 'direct': True, 'debridonly': True})
                        except:
                            log_utils.log('ultrahd_exc2', 1)
                            pass
                except:
                    log_utils.log('ultrahd_exc1', 1)
                    pass
            return sources
        except:
            log_utils.log('ultrahd_exc0', 1)
            return sources


    def resolve(self, url):
        return url

