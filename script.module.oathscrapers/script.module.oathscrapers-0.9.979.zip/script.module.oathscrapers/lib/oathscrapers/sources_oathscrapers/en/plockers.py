# -*- coding: UTF-8 -*-
# - Converted to py3/2 for TheOath


import re, base64, traceback

try: from urlparse import urlparse, parse_qs, urljoin
except ImportError: from urllib.parse import urlparse, parse_qs, urljoin
try: from urllib import urlencode, quote_plus
except ImportError: from urllib.parse import urlencode, quote_plus

import six

from oathscrapers.modules import client, cleantitle, source_utils, log_utils
from oathscrapers.sources_oathscrapers import cfScraper


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['www1.putlockers.gs']
        self.base_link = 'https://www8.putlockers.fm/'#'https://putlockerseries.unblocked.gdn'
        self.search_link = 'search-movies/%s.html'

    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'title': title, 'year': year, 'aliases': aliases}
            url = urlencode(url)
            return url
        except:
            failure = traceback.format_exc()
            log_utils.log('plockers0 Exception: \n' + str(failure))
            return

    def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
        try:
            url = {'imdb': imdb, 'tvdb': tvdb, 'tvshowtitle': tvshowtitle, 'year': year}
            url = urlencode(url)
            return url
        except:
            failure = traceback.format_exc()
            log_utils.log('plockers1 Exception: \n' + str(failure))
            return

    def episode(self, url, imdb, tvdb, title, premiered, season, episode):
        try:
            if url is None: return

            url = parse_qs(url)
            url = dict([(i, url[i][0]) if url[i] else (i, '') for i in url])
            url['title'], url['premiered'], url['season'], url['episode'] = title, premiered, season, episode
            url = urlencode(url)
            return url
        except:
            failure = traceback.format_exc()
            log_utils.log('plockers2 Exception: \n' + str(failure))
            return

    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url is None: return sources

            hostDict = hostprDict + hostDict

            data = parse_qs(url)
            data = dict([(i, data[i][0]) if data[i] else (i, '') for i in data])

            title = data['tvshowtitle'] if 'tvshowtitle' in data else data['title']
            title = cleantitle.get_query(title)
            hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode'])) if 'tvshowtitle' in data else data['year']
            query = '%s season %d' % (title, int(data['season'])) if 'tvshowtitle' in data else title
            query = re.sub('(\\\|/| -|:|;|\*|\?|"|\'|<|>|\|)', ' ', query)
            query = quote_plus(query)

            url = urljoin(self.base_link, self.search_link % query)

            ua = {'User-Agent': client.agent()}
            r = cfScraper.get(url, headers=ua).content
            r = six.ensure_text(r, errors='ignore')
            posts = client.parseDOM(r, 'div', attrs={'class': 'item'})
            posts = [(client.parseDOM(i, 'a', ret='href')[1],
                      client.parseDOM(i, 'a')[1],
                      re.findall('Release:\s*(\d{4})</', i, re.I | re.DOTALL)[1]) for i in posts if i]
            posts = [(i[0], client.parseDOM(i[1], 'i')[0], i[2]) for i in posts if i]

            if 'tvshowtitle' in data:
                sep = 'season %d' % int(data['season'])
                sepi = 'season-%1d/episode-%1d.html' % (int(data['season']), int(data['episode']))
                post = [i[0] for i in posts if sep in i[1].lower()][0]
                data = cfScraper.get(post, headers=ua).content
                data = six.ensure_text(data, errors='ignore')
                link = client.parseDOM(data, 'a', ret='href')
                link = [i for i in link if sepi in i][0]
            else:
                link = [i[0] for i in posts if cleantitle.get(i[1]) == cleantitle.get(title) and hdlr == i[2]][0]

            r = cfScraper.get(link, headers=ua).content
            r = six.ensure_text(r, errors='ignore')
            try:
                v = re.findall('document.write\(Base64.decode\("(.+?)"\)', r)[0]
                v = v.encode('utf-8')
                b64 = base64.b64decode(v)
                b64 = six.ensure_text(b64, errors='ignore')
                url = client.parseDOM(b64, 'iframe', ret='src')[0]
                try:
                    host = re.findall('([\w]+[.][\w]+)$', urlparse(url.strip().lower()).netloc)[0]
                    host = client.replaceHTMLCodes(host)
                    host = six.ensure_str(host)
                    valid, hoster = source_utils.is_host_valid(host, hostDict)
                    if valid:
                        sources.append({
                            'source': hoster,
                            'quality': 'SD',
                            'language': 'en',
                            'url': url.replace('\/', '/'),
                            'direct': False,
                            'debridonly': False
                        })
                except:
                    failure = traceback.format_exc()
                    log_utils.log('plockers4 Exception: \n' + str(failure))
                    pass
            except:
                failure = traceback.format_exc()
                log_utils.log('plockers3 Exception: \n' + str(failure))
                pass
            r = client.parseDOM(r, 'div', {'class': 'server_line'})
            r = [(client.parseDOM(i, 'a', ret='href')[0],
                  client.parseDOM(i, 'p', attrs={'class': 'server_servername'})[0]) for i in r]
            if r:
                for i in r:
                    try:
                        host = re.sub('Server|Link\s*\d+', '', i[1]).lower()
                        url = i[0].replace('\/', '/')
                        host = client.replaceHTMLCodes(host)
                        host = six.ensure_str(host)
                        if 'other' in host: continue
                        valid, hoster = source_utils.is_host_valid(host, hostDict)
                        if valid:
                            sources.append({
                                'source': hoster,
                                'quality': 'SD',
                                'language': 'en',
                                'url': url,
                                'direct': False,
                                'debridonly': False
                            })
                    except:
                        failure = traceback.format_exc()
                        log_utils.log('plockers5 Exception: \n' + str(failure))
                        pass
            return sources
        except:
            failure = traceback.format_exc()
            log_utils.log('plockers Exception: \n' + str(failure))
            return

    def resolve(self, url):
        if 'putlockers' in url:
            try:
                r = client.request(url)
                r = six.ensure_text(r, errors='ignore')
                try:
                    v = re.findall('document.write\(Base64.decode\("(.+?)"\)', r)[0]
                    v = v.encode('utf-8')
                    b64 = base64.b64decode(v)
                    b64 = six.ensure_text(b64, errors='ignore')
                    url = client.parseDOM(b64, 'iframe', ret='src')[0]
                    url = url.replace('///', '//')
                except:
                    u = client.parseDOM(r, 'div', attrs={'class': 'player'})
                    url = client.parseDOM(u, 'a', ret='href')[0]
            except:
                failure = traceback.format_exc()
                log_utils.log('plockersR Exception: \n' + str(failure))

            return url
        else:
            return url