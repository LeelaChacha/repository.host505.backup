# -*- coding: utf-8 -*-

tmdb_key = 'a041641d58395718cd8785a21be11d02'
tvdb_key = 'JMCO8LQHIXX76CGN'
fanarttv_key = '33653113b430cac1f9114dbd66fada2e'
yt_key = 'AIzaSyDw__6wPoiNWWxVdkaEKTg0ayGt8lL7P_c'
trakt_client_id = '8d96853f40d51bd0661b6378f53c34e36c5ce43f342b4a845b77987d466c264e'
trakt_secret = '586d034ba7378e6d68ccc819ea83c9fe97b9885b96a45dd69459b79cdde42e89'
orion_key = 'UHXKSL5KK8AF9H7NCEBB3JLABKGREELH'
